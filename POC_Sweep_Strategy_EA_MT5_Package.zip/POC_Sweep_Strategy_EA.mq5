//+------------------------------------------------------------------+
//| POC Sweep Strategy EA                                            |
//| Rule-based session POC sweep and reclaim Expert Advisor for MT5  |
//+------------------------------------------------------------------+
#property strict
#property version   "1.00"
#property description "POC Sweep Strategy Expert Advisor with risk controls and session profile analysis"
#property description "Automated directional bias, sweep/reclaim confirmation, news and spread protection"

#include <Trade/Trade.mqh>

CTrade trade;

//--- Risk and execution
input double InpRiskPercent                  = 2.0;       // Equity risk per trade (%)
input ulong  InpMagicNumber                  = 51826015;  // EA magic number
input int    InpDeviationPoints              = 30;        // Maximum execution deviation (points)
input int    InpMaxSpreadPoints               = 150;       // Maximum spread (points); 0 disables spread check
input bool   InpBlockIfAnySymbolPosition      = true;      // Avoid interfering with any open position on this symbol

//--- Session boundaries (broker server time)
input int    InpSession1Hour                  = 0;
input int    InpSession1Minute                = 0;
input bool   InpEnableSession2                = true;
input int    InpSession2Hour                  = 8;
input int    InpSession2Minute                = 0;
input bool   InpEnableSession3                = true;
input int    InpSession3Hour                  = 16;
input int    InpSession3Minute                = 0;
input int    InpMaxSessionOpenDelayMinutes    = 60;       // First available bar must be within this many minutes

//--- Volume profile / POC approximation
input int    InpProfileBinSizePoints          = 10;       // Price-bin size in symbol points
input int    InpMinimumProfileBars            = 30;       // Minimum one-minute bars for a profile
input int    InpPocNeutralZonePoints          = 10;       // Session-open distance treated as unclear
input int    InpMinimumSweepPenetrationPoints = 10;       // Minimum excursion through POC
input int    InpStopBufferPoints               = 5;        // Buffer beyond the signal candle extreme
input double InpAbnormalVolumeMultiplier      = 2.5;      // Spike if sweep-bar volume exceeds mean x this value
input double InpLargeCandleRangeMultiplier    = 2.0;      // Large candle if its range exceeds mean x this value
input int    InpAverageLookbackBars            = 20;       // Lookback for volume/range averages

//--- Take-profit and news protection
input double InpRewardRisk                     = 1.5;      // Target R multiple from the stop distance
input bool   InpUseEconomicCalendarFilter      = true;     // Block around high-impact calendar events
input string InpNewsCurrencies                 = "USD";    // Semicolon-delimited currency codes
input int    InpNewsMinutesBeforeAfter         = 5;        // Blackout minutes before/after event
input bool   InpFailClosedIfCalendarUnavailable= true;     // Live trading blocked if calendar cannot be queried
input bool   InpAllowTesterWithoutCalendar     = true;     // Tester may run core rules without historical calendar data

//--- Display
input bool   InpShowChartPanel                 = true;
input bool   InpDrawPocLine                    = true;

// The original strategy uses a fixed candle interval internally; this is not
// presented as an interface setting so that its entry rule cannot be changed accidentally.
#define SIGNAL_PERIOD PERIOD_M5

string   g_objectPrefix = "POCSW_";
string   g_panelName = "";
string   g_panelBgName = "";
string   g_pocLineName = "";
string   g_tradeKey = "";

datetime g_sessionStart = 0;
datetime g_previousSessionStart = 0;
datetime g_nextSessionStart = 0;
datetime g_lastSeenSignalBar = 0;

double   g_poc = 0.0;
double   g_previousSessionClose = 0.0;
double   g_sessionOpen = 0.0;
int      g_bias = 0;                 // +1 buy-only; -1 sell-only; 0 unclear/not ready
bool     g_profileReady = false;
bool     g_sessionPrepared = false;
bool     g_sessionBlocked = false;
bool     g_tradedThisSession = false;
bool     g_sweepActive = false;
int      g_sweepAge = 0;
double   g_sweepExtreme = 0.0;
datetime g_sweepBarTime = 0;
string   g_status = "Initializing";
string   g_calendarStatus = "Calendar checked at entry";

//+------------------------------------------------------------------+
//| Utility: volume-step precision                                   |
//+------------------------------------------------------------------+
int VolumeDigits(const double step)
  {
   for(int d=0; d<=8; d++)
     {
      if(MathAbs(step-NormalizeDouble(step,d))<1e-9)
         return d;
     }
   return 8;
  }

//+------------------------------------------------------------------+
//| Utility: snap price to trade tick size                           |
//+------------------------------------------------------------------+
double NormalizeTradePrice(const double price)
  {
   double tick_size=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(tick_size<=0.0)
      tick_size=_Point;
   return NormalizeDouble(MathRound(price/tick_size)*tick_size,_Digits);
  }

//+------------------------------------------------------------------+
//| Utility: session boundary datetime                               |
//+------------------------------------------------------------------+
datetime MakeBoundary(const datetime day_anchor,const int hour,const int minute)
  {
   MqlDateTime dt;
   TimeToStruct(day_anchor,dt);
   dt.hour=hour;
   dt.min=minute;
   dt.sec=0;
   return StructToTime(dt);
  }

//+------------------------------------------------------------------+
//| Read configured session boundary list                            |
//+------------------------------------------------------------------+
int GetEnabledSessionTimes(int &minutes[])
  {
   ArrayResize(minutes,0);
   int m=InpSession1Hour*60+InpSession1Minute;
   ArrayResize(minutes,ArraySize(minutes)+1);
   minutes[ArraySize(minutes)-1]=m;
   if(InpEnableSession2)
     {
      m=InpSession2Hour*60+InpSession2Minute;
      ArrayResize(minutes,ArraySize(minutes)+1);
      minutes[ArraySize(minutes)-1]=m;
     }
   if(InpEnableSession3)
     {
      m=InpSession3Hour*60+InpSession3Minute;
      ArrayResize(minutes,ArraySize(minutes)+1);
      minutes[ArraySize(minutes)-1]=m;
     }
   return ArraySize(minutes);
  }

//+------------------------------------------------------------------+
//| Determine current, previous and next configured session bounds   |
//+------------------------------------------------------------------+
bool GetSessionBounds(const datetime now,datetime &previous_start,datetime &current_start,datetime &next_start)
  {
   int minutes[];
   int count=GetEnabledSessionTimes(minutes);
   if(count<1)
      return false;

   MqlDateTime ndt;
   TimeToStruct(now,ndt);
   ndt.hour=0;
   ndt.min=0;
   ndt.sec=0;
   datetime midnight=StructToTime(ndt);

   datetime boundaries[];
   ArrayResize(boundaries,0);
   for(int day_offset=-1; day_offset<=1; day_offset++)
     {
      datetime day_anchor=midnight+(datetime)(day_offset*86400);
      for(int i=0; i<count; i++)
        {
         int h=minutes[i]/60;
         int mn=minutes[i]%60;
         int sz=ArraySize(boundaries);
         ArrayResize(boundaries,sz+1);
         boundaries[sz]=MakeBoundary(day_anchor,h,mn);
        }
     }

   int n=ArraySize(boundaries);
   for(int i=0; i<n-1; i++)
      for(int j=i+1; j<n; j++)
         if(boundaries[j]<boundaries[i])
           {
            datetime tmp=boundaries[i];
            boundaries[i]=boundaries[j];
            boundaries[j]=tmp;
           }

   int idx=-1;
   for(int i=0; i<n; i++)
     {
      if(boundaries[i]<=now)
         idx=i;
      else
         break;
     }
   if(idx<1 || idx>=n-1)
      return false;
   previous_start=boundaries[idx-1];
   current_start=boundaries[idx];
   next_start=boundaries[idx+1];
   return (previous_start<current_start && current_start<next_start);
  }

//+------------------------------------------------------------------+
//| Global variable key for one-trade-per-session persistence        |
//+------------------------------------------------------------------+
string BuildTradeKey()
  {
   string sym=_Symbol;
   StringReplace(sym,".","_");
   StringReplace(sym,"#","_");
   StringReplace(sym," ","_");
   return "POCSWP_"+(string)AccountInfoInteger(ACCOUNT_LOGIN)+"_"+(string)InpMagicNumber+"_"+sym;
  }

//+------------------------------------------------------------------+
//| Check persisted trade marker                                     |
//+------------------------------------------------------------------+
bool WasTradedThisSession()
  {
   if(g_tradeKey=="" || !GlobalVariableCheck(g_tradeKey))
      return false;
   double stored=GlobalVariableGet(g_tradeKey);
   return (MathAbs(stored-(double)g_sessionStart)<1.0);
  }

//+------------------------------------------------------------------+
//| Price selection for tick-profile accumulation                    |
//+------------------------------------------------------------------+
double TickPrice(const MqlTick &tick)
  {
   if(tick.last>0.0)
      return tick.last;
   if(tick.bid>0.0 && tick.ask>0.0)
      return (tick.bid+tick.ask)*0.5;
   if(tick.bid>0.0)
      return tick.bid;
   if(tick.ask>0.0)
      return tick.ask;
   return 0.0;
  }

//+------------------------------------------------------------------+
//| Calculate volume-profile POC from prior session                  |
//| Uses tick data when available; M1 tick-volume fallback otherwise.|
//+------------------------------------------------------------------+
bool CalculateSessionProfile(const datetime start_time,const datetime end_time,double &poc,double &last_close)
  {
   if(end_time<=start_time)
      return false;

   MqlRates rates[];
   ArraySetAsSeries(rates,false);
   int copied=CopyRates(_Symbol,PERIOD_M1,start_time,end_time,rates);
   if(copied<=0)
      return false;

   int valid=0;
   double min_price=1.0e100;
   double max_price=0.0;
   last_close=0.0;
   for(int i=0; i<copied; i++)
     {
      if(rates[i].time<start_time || rates[i].time>=end_time)
         continue;
      valid++;
      min_price=MathMin(min_price,rates[i].low);
      max_price=MathMax(max_price,rates[i].high);
      last_close=rates[i].close;
     }
   if(valid<InpMinimumProfileBars || min_price>=max_price || last_close<=0.0)
      return false;

   double trade_tick=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(trade_tick<=0.0)
      trade_tick=_Point;
   double bin_size=MathMax(trade_tick,(double)MathMax(1,InpProfileBinSizePoints)*_Point);
   long min_bucket=(long)MathFloor(min_price/bin_size);
   long max_bucket=(long)MathFloor(max_price/bin_size);
   long bin_count_long=max_bucket-min_bucket+1;
   if(bin_count_long<1 || bin_count_long>200000)
      return false;
   int bin_count=(int)bin_count_long;

   double weights[];
   ArrayResize(weights,bin_count);
   ArrayInitialize(weights,0.0);
   long tick_count=0;

   // Fetch ticks in hourly chunks to constrain memory usage.
   datetime cursor=start_time;
   while(cursor<end_time)
     {
      datetime batch_end=cursor+3600;
      if(batch_end>end_time)
         batch_end=end_time;
      MqlTick ticks[];
      ulong from_msc=(ulong)cursor*1000;
      ulong to_msc=(ulong)batch_end*1000-1;
      int n_ticks=CopyTicksRange(_Symbol,ticks,COPY_TICKS_ALL,from_msc,to_msc);
      if(n_ticks>0)
        {
         for(int t=0; t<n_ticks; t++)
           {
            double price=TickPrice(ticks[t]);
            if(price<=0.0)
               continue;
            long bucket=(long)MathFloor(price/bin_size);
            int index=(int)(bucket-min_bucket);
            if(index<0 || index>=bin_count)
               continue;
            double weight=1.0;
            if(ticks[t].volume_real>0.0)
               weight=ticks[t].volume_real;
            else if(ticks[t].volume>0)
               weight=(double)ticks[t].volume;
            weights[index]+=weight;
            tick_count++;
           }
        }
      cursor=batch_end;
     }

   // Fallback: allocate each M1 candle's tick volume to its typical price.
   // It is a deterministic approximation, not centralized exchange volume.
   if(tick_count<20)
     {
      ArrayInitialize(weights,0.0);
      for(int i=0; i<copied; i++)
        {
         if(rates[i].time<start_time || rates[i].time>=end_time)
            continue;
         double typical=(rates[i].high+rates[i].low+rates[i].close)/3.0;
         long bucket=(long)MathFloor(typical/bin_size);
         int index=(int)(bucket-min_bucket);
         if(index<0 || index>=bin_count)
            continue;
         double weight=(double)rates[i].tick_volume;
         if(weight<=0.0)
            weight=1.0;
         weights[index]+=weight;
        }
     }

   int best_index=-1;
   double best_weight=-1.0;
   for(int i=0; i<bin_count; i++)
     {
      if(weights[i]>best_weight)
        {
         best_weight=weights[i];
         best_index=i;
        }
     }
   if(best_index<0 || best_weight<=0.0)
      return false;

   poc=((double)(min_bucket+best_index)+0.5)*bin_size;
   poc=NormalizeTradePrice(poc);
   return (poc>0.0);
  }

//+------------------------------------------------------------------+
//| Get first available session-open candle                          |
//+------------------------------------------------------------------+
bool ReadSessionOpen(const datetime session_start,const datetime session_end,double &open_price)
  {
   datetime search_end=session_start+(datetime)(MathMax(1,InpMaxSessionOpenDelayMinutes)*60);
   if(search_end>session_end)
      search_end=session_end;
   MqlRates rates[];
   ArraySetAsSeries(rates,false);
   int copied=CopyRates(_Symbol,PERIOD_M1,session_start,search_end,rates);
   if(copied<=0)
      return false;
   for(int i=0; i<copied; i++)
     {
      if(rates[i].time>=session_start && rates[i].time<search_end && rates[i].open>0.0)
        {
         open_price=rates[i].open;
         return true;
        }
     }
   return false;
  }

//+------------------------------------------------------------------+
//| Reset state at each configured session                           |
//+------------------------------------------------------------------+
void ResetForSession(const datetime prev_start,const datetime current_start,const datetime next_start)
  {
   g_previousSessionStart=prev_start;
   g_sessionStart=current_start;
   g_nextSessionStart=next_start;
   g_poc=0.0;
   g_previousSessionClose=0.0;
   g_sessionOpen=0.0;
   g_bias=0;
   g_profileReady=false;
   g_sessionPrepared=false;
   g_sessionBlocked=false;
   g_tradedThisSession=WasTradedThisSession();
   g_sweepActive=false;
   g_sweepAge=0;
   g_sweepExtreme=0.0;
   g_sweepBarTime=0;
   g_status="Building reference profile";
  }

//+------------------------------------------------------------------+
//| Prepare POC, open bias, and gap filter for the active session    |
//+------------------------------------------------------------------+
void PrepareSessionIfPossible()
  {
   if(g_sessionPrepared)
      return;

   if(!g_profileReady)
     {
      double candidate_poc=0.0;
      double previous_close=0.0;
      if(!CalculateSessionProfile(g_previousSessionStart,g_sessionStart,candidate_poc,previous_close))
        {
         g_status="Waiting: insufficient profile history";
         return;
        }
      g_poc=candidate_poc;
      g_previousSessionClose=previous_close;
      g_profileReady=true;
      if(InpDrawPocLine)
        {
         if(ObjectFind(0,g_pocLineName)<0)
            ObjectCreate(0,g_pocLineName,OBJ_HLINE,0,0,g_poc);
         ObjectSetDouble(0,g_pocLineName,OBJPROP_PRICE,g_poc);
         ObjectSetInteger(0,g_pocLineName,OBJPROP_COLOR,clrGold);
         ObjectSetInteger(0,g_pocLineName,OBJPROP_STYLE,STYLE_DASH);
         ObjectSetInteger(0,g_pocLineName,OBJPROP_WIDTH,2);
         ObjectSetInteger(0,g_pocLineName,OBJPROP_SELECTABLE,false);
         ObjectSetInteger(0,g_pocLineName,OBJPROP_HIDDEN,true);
        }
     }

   double open_price=0.0;
   if(!ReadSessionOpen(g_sessionStart,g_nextSessionStart,open_price))
     {
      g_status="Waiting: session opening price unavailable";
      return;
     }
   g_sessionOpen=open_price;

   double neutral=(double)MathMax(0,InpPocNeutralZonePoints)*_Point;
   if(g_sessionOpen>g_poc+neutral)
      g_bias=1;
   else if(g_sessionOpen<g_poc-neutral)
      g_bias=-1;
   else
     {
      g_bias=0;
      g_sessionBlocked=true;
      g_status="No trade: session opened too close to POC";
      g_sessionPrepared=true;
      return;
     }

   // If the previous close and session open are on opposite sides of POC,
   // price crossed the reference level in a gap. Treat it as a breakout risk.
   double gap_min=(double)MathMax(0,InpMinimumSweepPenetrationPoints)*_Point;
   bool previous_below=(g_previousSessionClose<g_poc);
   bool open_below=(g_sessionOpen<g_poc);
   if(previous_below!=open_below && MathAbs(g_sessionOpen-g_previousSessionClose)>=gap_min)
     {
      g_sessionBlocked=true;
      g_status="Blocked: session opened with a gap through POC";
      g_sessionPrepared=true;
      return;
     }

   g_sessionPrepared=true;
   if(g_tradedThisSession)
      g_status="Session trade already used";
   else
      g_status=(g_bias>0 ? "BUY bias: wait for downside sweep" : "SELL bias: wait for upside sweep");
  }

//+------------------------------------------------------------------+
//| Prepare current session state                                    |
//+------------------------------------------------------------------+
void EnsureCurrentSession()
  {
   datetime prev_start=0,current_start=0,next_start=0;
   if(!GetSessionBounds(TimeCurrent(),prev_start,current_start,next_start))
     {
      g_status="Invalid session schedule";
      return;
     }
   if(current_start!=g_sessionStart)
      ResetForSession(prev_start,current_start,next_start);
   PrepareSessionIfPossible();
  }

//+------------------------------------------------------------------+
//| High-impact economic-calendar window check                       |
//+------------------------------------------------------------------+
bool IsNewsWindow(string &reason)
  {
   reason="";
   if(!InpUseEconomicCalendarFilter)
     {
      g_calendarStatus="Calendar filter disabled";
      return false;
     }

   datetime now=TimeCurrent();
   datetime from_time=now-(datetime)(MathMax(0,InpNewsMinutesBeforeAfter)*60);
   datetime to_time=now+(datetime)(MathMax(0,InpNewsMinutesBeforeAfter)*60);
   string currencies[];
   int count=StringSplit(InpNewsCurrencies,(ushort)StringGetCharacter(";",0),currencies);
   if(count<=0)
     {
      reason="News filter blocked: no calendar currencies configured";
      g_calendarStatus="Currency configuration invalid";
      return true;
     }

   bool any_query_succeeded=false;
   for(int c=0; c<count; c++)
     {
      StringTrimLeft(currencies[c]);
      StringTrimRight(currencies[c]);
      if(currencies[c]=="")
         continue;
      MqlCalendarValue values[];
      ResetLastError();
      int found=CalendarValueHistory(values,from_time,to_time,NULL,currencies[c]);
      if(found<0)
         continue;
      any_query_succeeded=true;
      for(int i=0; i<found; i++)
        {
         MqlCalendarEvent event_info;
         if(!CalendarEventById(values[i].event_id,event_info))
            continue;
         if(event_info.importance!=CALENDAR_IMPORTANCE_HIGH)
            continue;
         if(values[i].time>=from_time && values[i].time<=to_time)
           {
            reason="Blocked: high-impact news window";
            g_calendarStatus="High-impact event nearby";
            return true;
           }
        }
     }

   if(any_query_succeeded)
     {
      g_calendarStatus="Calendar checked: no nearby high-impact event";
      return false;
     }

   if((bool)MQLInfoInteger(MQL_TESTER) && InpAllowTesterWithoutCalendar)
     {
      g_calendarStatus="Tester: calendar data unavailable; news rule not verified";
      return false;
     }
   if(InpFailClosedIfCalendarUnavailable)
     {
      reason="Blocked: economic calendar unavailable";
      g_calendarStatus="Calendar unavailable: trading blocked";
      return true;
     }
   g_calendarStatus="Calendar unavailable: fail-open enabled";
   return false;
  }

//+------------------------------------------------------------------+
//| Average completed-candle volume                                  |
//+------------------------------------------------------------------+
double AverageVolume(const int start_shift,const int count)
  {
   if(count<=0)
      return 0.0;
   double sum=0.0;
   int actual=0;
   for(int shift=start_shift; shift<start_shift+count; shift++)
     {
      long volume=iVolume(_Symbol,SIGNAL_PERIOD,shift);
      if(volume<0)
         continue;
      sum+=(double)volume;
      actual++;
     }
   if(actual<=0)
      return 0.0;
   return sum/(double)actual;
  }

//+------------------------------------------------------------------+
//| Average completed-candle range                                   |
//+------------------------------------------------------------------+
double AverageRange(const int start_shift,const int count)
  {
   if(count<=0)
      return 0.0;
   double sum=0.0;
   int actual=0;
   for(int shift=start_shift; shift<start_shift+count; shift++)
     {
      double h=iHigh(_Symbol,SIGNAL_PERIOD,shift);
      double l=iLow(_Symbol,SIGNAL_PERIOD,shift);
      if(h<=0.0 || l<=0.0 || h<l)
         continue;
      sum+=(h-l);
      actual++;
     }
   if(actual<=0)
      return 0.0;
   return sum/(double)actual;
  }

//+------------------------------------------------------------------+
//| Check whether any position exists for this symbol                |
//+------------------------------------------------------------------+
bool SymbolPositionExists()
  {
   if(!InpBlockIfAnySymbolPosition)
      return false;
   return PositionSelect(_Symbol);
  }

//+------------------------------------------------------------------+
//| Risk-based volume calculation                                    |
//+------------------------------------------------------------------+
bool CalculateRiskVolume(const bool is_buy,const double entry,const double stop,double &lots,string &why)
  {
   lots=0.0;
   why="";
   if(entry<=0.0 || stop<=0.0 || (is_buy && stop>=entry) || (!is_buy && stop<=entry))
     {
      why="Invalid stop side";
      return false;
     }

   double stop_level=(double)SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)*_Point;
   if(MathAbs(entry-stop)<stop_level+_Point*0.1)
     {
      why="Stop too close for broker rules";
      return false;
     }

   double risk_money=AccountInfoDouble(ACCOUNT_EQUITY)*InpRiskPercent/100.0;
   if(risk_money<=0.0)
     {
      why="Risk amount is zero";
      return false;
     }
   double profit_one_lot=0.0;
   ENUM_ORDER_TYPE order_type=(is_buy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
   if(!OrderCalcProfit(order_type,_Symbol,1.0,entry,stop,profit_one_lot))
     {
      why="Unable to calculate stop-loss value";
      return false;
     }
   double loss_per_lot=MathAbs(profit_one_lot);
   if(loss_per_lot<=0.0)
     {
      why="Calculated loss per lot is invalid";
      return false;
     }

   double raw_lots=risk_money/loss_per_lot;
   double min_lot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double max_lot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX);
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(step<=0.0 || min_lot<=0.0 || max_lot<min_lot)
     {
      why="Broker volume settings unavailable";
      return false;
     }

   raw_lots=MathMin(raw_lots,max_lot);
   lots=MathFloor(raw_lots/step+1e-9)*step;
   lots=NormalizeDouble(lots,VolumeDigits(step));
   if(lots<min_lot)
     {
      lots=0.0;
      why="Minimum lot would exceed configured risk; trade skipped";
      return false;
     }
   return true;
  }

//+------------------------------------------------------------------+
//| Place one trade using the strategy's candle-based stop           |
//+------------------------------------------------------------------+
bool PlaceSweepTrade(const bool is_buy,const double signal_high,const double signal_low,const double signal_range,const double average_range)
  {
   string news_reason="";
   if(IsNewsWindow(news_reason))
     {
      g_status=news_reason;
      return false;
     }

   if(InpMaxSpreadPoints>0)
     {
      MqlTick tick;
      if(!SymbolInfoTick(_Symbol,tick) || tick.ask<=0.0 || tick.bid<=0.0)
        {
         g_status="Blocked: live quote unavailable";
         return false;
        }
      int spread=(int)MathRound((tick.ask-tick.bid)/_Point);
      if(spread>InpMaxSpreadPoints)
        {
         g_status="Blocked: spread exceeds limit";
         return false;
        }
     }

   if(SymbolPositionExists())
     {
      g_status="Blocked: a position is already open on this symbol";
      return false;
     }

   MqlTick quote;
   if(!SymbolInfoTick(_Symbol,quote) || quote.ask<=0.0 || quote.bid<=0.0)
     {
      g_status="Blocked: live quote unavailable";
      return false;
     }
   double entry=(is_buy ? quote.ask : quote.bid);
   bool large_candle=(average_range>0.0 && signal_range>average_range*InpLargeCandleRangeMultiplier);
   double stop=0.0;
   if(large_candle)
      stop=g_poc;
   else if(is_buy)
      stop=signal_low-(double)MathMax(0,InpStopBufferPoints)*_Point;
   else
      stop=signal_high+(double)MathMax(0,InpStopBufferPoints)*_Point;

   stop=NormalizeTradePrice(stop);
   if((is_buy && stop>=entry) || (!is_buy && stop<=entry))
     {
      g_status="Blocked: calculated stop is on the wrong side";
      return false;
     }

   double risk_distance=MathAbs(entry-stop);
   double target=(is_buy ? entry+risk_distance*InpRewardRisk : entry-risk_distance*InpRewardRisk);
   target=NormalizeTradePrice(target);
   if((is_buy && target<=entry) || (!is_buy && target>=entry))
     {
      g_status="Blocked: calculated target is invalid";
      return false;
     }

   double lots=0.0;
   string sizing_reason="";
   if(!CalculateRiskVolume(is_buy,entry,stop,lots,sizing_reason))
     {
      g_status="Blocked: "+sizing_reason;
      return false;
     }

   trade.SetExpertMagicNumber(InpMagicNumber);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetTypeFillingBySymbol(_Symbol);
   trade.SetAsyncMode(false);

   string comment=(is_buy ? "POC Sweep BUY" : "POC Sweep SELL");
   bool sent=(is_buy ? trade.Buy(lots,_Symbol,0.0,stop,target,comment)
                     : trade.Sell(lots,_Symbol,0.0,stop,target,comment));
   uint rc=trade.ResultRetcode();
   bool accepted=(sent && (rc==TRADE_RETCODE_DONE || rc==TRADE_RETCODE_PLACED || rc==TRADE_RETCODE_DONE_PARTIAL));
   if(!accepted)
     {
      g_status="Order rejected: "+trade.ResultRetcodeDescription();
      return false;
     }

   g_tradedThisSession=true;
   GlobalVariableSet(g_tradeKey,(double)g_sessionStart);
   GlobalVariablesFlush();
   g_sweepActive=false;
   g_status=(is_buy ? "BUY opened" : "SELL opened");
   if(large_candle)
      g_status+="; POC stop used for large candle";
   return true;
  }

//+------------------------------------------------------------------+
//| Process one newly closed signal candle                           |
//+------------------------------------------------------------------+
void ProcessClosedSignalCandle()
  {
   if(!g_sessionPrepared || g_sessionBlocked || g_bias==0)
      return;
   if(g_tradedThisSession)
     {
      g_status="Session trade already used";
      return;
     }

   if(SymbolPositionExists())
     {
      g_status="Waiting: a position is already open on this symbol";
      return;
     }

   datetime bar_time=iTime(_Symbol,SIGNAL_PERIOD,1);
   if(bar_time<=0)
      return;
   double open=iOpen(_Symbol,SIGNAL_PERIOD,1);
   double high=iHigh(_Symbol,SIGNAL_PERIOD,1);
   double low=iLow(_Symbol,SIGNAL_PERIOD,1);
   double close=iClose(_Symbol,SIGNAL_PERIOD,1);
   long volume=iVolume(_Symbol,SIGNAL_PERIOD,1);
   if(open<=0.0 || high<=0.0 || low<=0.0 || close<=0.0 || high<low)
      return;

   int lookback=MathMax(1,InpAverageLookbackBars);
   double avg_volume=AverageVolume(2,lookback);
   double avg_range=AverageRange(2,lookback);
   double candle_range=high-low;
   double penetration=(double)MathMax(0,InpMinimumSweepPenetrationPoints)*_Point;

   // A breakout-like abnormal-volume sweep invalidates this session.
   bool extreme_through=(g_bias>0 ? low<=g_poc-penetration : high>=g_poc+penetration);
   if(extreme_through && avg_volume>0.0 && (double)volume>avg_volume*InpAbnormalVolumeMultiplier)
     {
      g_sessionBlocked=true;
      g_sweepActive=false;
      g_status="Blocked: abnormal volume spike at POC";
      return;
     }

   if(!g_sweepActive)
     {
      if(!extreme_through)
        {
         g_status=(g_bias>0 ? "BUY bias: waiting for downside sweep" : "SELL bias: waiting for upside sweep");
         return;
        }

      g_sweepActive=true;
      g_sweepAge=0;
      g_sweepBarTime=bar_time;
      g_sweepExtreme=(g_bias>0 ? low : high);

      // A single candle can sweep and reclaim, as long as it closes back
      // on the session-open bias side of POC.
      bool reclaimed=(g_bias>0 ? close>g_poc : close<g_poc);
      if(reclaimed)
        {
         PlaceSweepTrade(g_bias>0,high,low,candle_range,avg_range);
         g_sweepActive=false;
         return;
        }
      g_status="Sweep detected: waiting for close back across POC";
      return;
     }

   // Keep the most extreme sweep level for diagnostics; the normal stop
   // still follows the strategy's reclaim-candle extreme.
   if(g_bias>0)
      g_sweepExtreme=MathMin(g_sweepExtreme,low);
   else
      g_sweepExtreme=MathMax(g_sweepExtreme,high);
   g_sweepAge++;

   if(g_sweepAge>4)
     {
      g_sweepActive=false;
      g_status="Setup expired: no reclaim within four candles";
      return;
     }

   bool reclaim=(g_bias>0 ? close>g_poc : close<g_poc);
   if(reclaim)
     {
      PlaceSweepTrade(g_bias>0,high,low,candle_range,avg_range);
      g_sweepActive=false;
      return;
     }

   g_status="Sweep active: awaiting valid reclaim";
  }

//+------------------------------------------------------------------+
//| Chart panel creation                                             |
//+------------------------------------------------------------------+
void CreatePanel()
  {
   if(!InpShowChartPanel)
      return;
   if(ObjectFind(0,g_panelBgName)<0)
      ObjectCreate(0,g_panelBgName,OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_XDISTANCE,10);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_YDISTANCE,18);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_XSIZE,370);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_YSIZE,165);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_BGCOLOR,clrMidnightBlue);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_COLOR,clrSlateGray);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_BORDER_TYPE,BORDER_FLAT);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_BACK,false);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,g_panelBgName,OBJPROP_HIDDEN,true);

   if(ObjectFind(0,g_panelName)<0)
      ObjectCreate(0,g_panelName,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,g_panelName,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,g_panelName,OBJPROP_XDISTANCE,20);
   ObjectSetInteger(0,g_panelName,OBJPROP_YDISTANCE,25);
   ObjectSetInteger(0,g_panelName,OBJPROP_COLOR,clrWhite);
   ObjectSetInteger(0,g_panelName,OBJPROP_FONTSIZE,9);
   ObjectSetString(0,g_panelName,OBJPROP_FONT,"Consolas");
   ObjectSetInteger(0,g_panelName,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,g_panelName,OBJPROP_HIDDEN,true);
  }

//+------------------------------------------------------------------+
//| Update chart panel                                               |
//+------------------------------------------------------------------+
void UpdatePanel()
  {
   if(!InpShowChartPanel)
      return;
   CreatePanel();

   string bias_text="UNDEFINED";
   if(g_bias>0) bias_text="BUY ONLY";
   if(g_bias<0) bias_text="SELL ONLY";
   string poc_text=(g_poc>0.0 ? DoubleToString(g_poc,_Digits) : "building...");
   string open_text=(g_sessionOpen>0.0 ? DoubleToString(g_sessionOpen,_Digits) : "pending");
   string session_text=(g_sessionStart>0 ? TimeToString(g_sessionStart,TIME_DATE|TIME_MINUTES) : "pending");
   string next_text=(g_nextSessionStart>0 ? TimeToString(g_nextSessionStart,TIME_DATE|TIME_MINUTES) : "pending");
   string trade_text=(g_tradedThisSession ? "USED" : "AVAILABLE");
   string block_text=(g_sessionBlocked ? "YES" : "NO");

   string text_value="POC SWEEP STRATEGY EA\n";
   text_value+="Symbol: "+_Symbol+"\n";
   text_value+="Session start: "+session_text+"\n";
   text_value+="Next session:  "+next_text+"\n";
   text_value+="Reference POC: "+poc_text+"\n";
   text_value+="Session open: "+open_text+"\n";
   text_value+="Bias: "+bias_text+" | Trade used: "+trade_text+"\n";
   text_value+="Session blocked: "+block_text+"\n";
   text_value+="Risk: "+DoubleToString(InpRiskPercent,2)+"% equity | Target: "+DoubleToString(InpRewardRisk,2)+"R\n";
   text_value+="Status: "+g_status+"\n";
   text_value+="News: "+g_calendarStatus;
   ObjectSetString(0,g_panelName,OBJPROP_TEXT,text_value);
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| Input validation                                                 |
//+------------------------------------------------------------------+
bool ValidateInputs()
  {
   if(InpRiskPercent<=0.0 || InpRiskPercent>10.0)
     {
      Print("RiskPercent must be > 0 and <= 10.");
      return false;
     }
   if(InpSession1Hour<0 || InpSession1Hour>23 || InpSession1Minute<0 || InpSession1Minute>59 ||
      InpSession2Hour<0 || InpSession2Hour>23 || InpSession2Minute<0 || InpSession2Minute>59 ||
      InpSession3Hour<0 || InpSession3Hour>23 || InpSession3Minute<0 || InpSession3Minute>59)
     {
      Print("Session hours/minutes are invalid.");
      return false;
     }
   if(InpRewardRisk<=0.0 || InpProfileBinSizePoints<1 || InpMinimumProfileBars<1 || InpAverageLookbackBars<1)
     {
      Print("Reward-to-risk, profile bin, profile bars, and average lookback inputs must be positive.");
      return false;
     }
   int mins[];
   GetEnabledSessionTimes(mins);
   for(int i=0; i<ArraySize(mins); i++)
      for(int j=i+1; j<ArraySize(mins); j++)
         if(mins[i]==mins[j])
           {
            Print("Enabled session start times must be unique.");
            return false;
           }
   return true;
  }

//+------------------------------------------------------------------+
//| Expert initialization                                            |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(!ValidateInputs())
      return INIT_PARAMETERS_INCORRECT;

   g_objectPrefix="POCSW_"+(string)InpMagicNumber+"_";
   g_panelName=g_objectPrefix+"PANEL";
   g_panelBgName=g_objectPrefix+"PANEL_BG";
   g_pocLineName=g_objectPrefix+"POC";
   g_tradeKey=BuildTradeKey();

   trade.SetExpertMagicNumber(InpMagicNumber);
   trade.SetDeviationInPoints(InpDeviationPoints);
   trade.SetTypeFillingBySymbol(_Symbol);
   trade.SetAsyncMode(false);

   g_lastSeenSignalBar=iTime(_Symbol,SIGNAL_PERIOD,0);
   CreatePanel();
   EnsureCurrentSession();
   UpdatePanel();
   Print("POC Sweep Strategy EA initialized on ",_Symbol,". Verify session boundaries against broker server time.");
   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
//| Expert shutdown                                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   ObjectsDeleteAll(0,g_objectPrefix);
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| Expert tick                                                      |
//+------------------------------------------------------------------+
void OnTick()
  {
   EnsureCurrentSession();

   datetime current_signal_bar=iTime(_Symbol,SIGNAL_PERIOD,0);
   if(current_signal_bar>0)
     {
      if(g_lastSeenSignalBar==0)
         g_lastSeenSignalBar=current_signal_bar;
      else if(current_signal_bar!=g_lastSeenSignalBar)
        {
         g_lastSeenSignalBar=current_signal_bar;
         ProcessClosedSignalCandle();
        }
     }
   UpdatePanel();
  }
//+------------------------------------------------------------------+
