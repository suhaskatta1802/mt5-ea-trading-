# POC Sweep Strategy EA — MT5

A rule-driven MetaTrader 5 Expert Advisor based on the supplied POC Sweep Strategy image. It trades the chart symbol and defaults to **2% of account equity risk per trade**, BUY and SELL according to the session-open bias, and a fixed **1.5R** target.

The reported win-rate claim shown in the source image is not treated as verified performance. No profitability is guaranteed; validate the EA with realistic spread, commissions, slippage, and out-of-sample data before risking capital.

## What it automates

1. Builds a price-volume histogram for the immediately preceding configured session and marks the Point of Control (POC).
2. Reads the first available bar at the new session open. Above POC gives BUY-only bias; below POC gives SELL-only bias; too close to POC means no trade.
3. Looks for price to sweep through POC against the bias by a configurable minimum distance, followed by a candle close back on the bias side within four subsequent candles.
4. Enters at market after the closed-candle reclaim. The stop is beyond the reclaim candle's low/high by a configurable buffer. When that candle is unusually large, the stop is set at POC as specified in the source rules.
5. Sets take profit to 1.5 times the entry-to-stop distance.
6. Limits the EA to one filled trade per symbol and configured session, with a terminal Global Variable marker to prevent a duplicate after a restart.
7. Blocks abnormal-volume sweeps, session-open gaps through POC, wide spreads, nearby high-impact calendar events, and ambiguous session-open bias.

## Important implementation detail: POC

MT5 broker feeds do not all provide exchange-grade volume-at-price data. The EA first aggregates available tick data by price bucket. If tick data is unavailable or too sparse, it uses a deterministic approximation: each one-minute candle's tick volume is assigned to that candle's typical price. This fallback is not equivalent to an exchange's full Volume Profile. Review the plotted POC against your data provider's profile tool before live use.

## Installation

1. In MT5, choose **File → Open Data Folder**.
2. Open `MQL5/Experts` and copy `POC_Sweep_Strategy_EA.mq5` there.
3. Open MetaEditor from MT5, open the file, and press **Compile**.
4. In MT5, refresh **Navigator → Expert Advisors** and attach the EA to the desired chart.
5. Enable Algo Trading and confirm that live trading is permitted in the EA's Common settings.
6. Run the Strategy Tester, inspect individual trades and rejected setups, then forward-test on a demo account.

## Configure sessions first

The default session boundaries are **00:00, 08:00, and 16:00 broker-server time**. These are placeholders, not universal market-session times. Configure them to the session breaks you actually use, using the broker's server clock (not your computer's local clock). The POC for a session is calculated from the immediately preceding configured session interval.

You can disable Session 2 or Session 3 and edit the start hour/minute fields. Enabled start times must be unique. The current session is not considered ready until the preceding session has enough one-minute bars to calculate a profile and a session-open price is available.

## Main inputs

| Input | Default | Meaning |
|---|---:|---|
| `InpRiskPercent` | 2.0 | Equity percentage targeted at the stop-loss distance |
| `InpMaxSpreadPoints` | 150 | Maximum allowed spread in symbol points; set 0 to disable |
| `InpProfileBinSizePoints` | 10 | Price-bin width used to calculate the POC |
| `InpPocNeutralZonePoints` | 10 | Session-open distance around POC treated as unclear |
| `InpMinimumSweepPenetrationPoints` | 10 | Minimum price excursion through POC for a sweep |
| `InpStopBufferPoints` | 5 | Buffer beyond the reclaim candle's extreme |
| `InpAbnormalVolumeMultiplier` | 2.5 | Sweep is rejected if volume exceeds this multiple of the recent mean |
| `InpLargeCandleRangeMultiplier` | 2.0 | Reclaim candle beyond this multiple uses POC for the stop |
| `InpRewardRisk` | 1.5 | Target in R multiples |
| `InpNewsCurrencies` | `USD` | Semicolon-separated calendar currencies to check |
| `InpNewsMinutesBeforeAfter` | 5 | Calendar blackout before and after high-impact events |

Point-based values must be adjusted for the broker's symbol digits, tick size, and spread. The EA uses the chart symbol, so broker-specific symbols such as `XAUUSD.a` or an index CFD suffix are supported if that symbol is tradeable.

## News filter behavior

The EA queries MT5's built-in economic calendar for high-impact events in the configured currency list. For live/demo operation it fails closed by default when the calendar cannot be queried. Some Strategy Tester environments do not provide historical calendar data; with `InpAllowTesterWithoutCalendar=true`, the tester can evaluate core entries but the historical news blackout is **not verified**. Do not interpret such a backtest as proving the news filter was respected. For stricter testing, set that input to false, or arrange a separate historical news-data workflow.

## Risk and execution safeguards

- Volume is calculated using `OrderCalcProfit` so that the estimated loss at the stop is approximately the configured equity risk, subject to gaps/slippage/fees.
- If the broker's minimum volume would exceed the configured risk, the EA skips the trade rather than rounding up.
- If the stop violates the broker's minimum stop distance or is on the wrong side of price, the EA skips the trade.
- If enabled, the EA avoids a new order while any position is already open on the same symbol, preventing interference with manual positions or other strategies.
- It persists the one-trade-per-session marker using an MT5 terminal Global Variable.
- It does not martingale, average down, add positions, or re-enter after a filled trade within the same configured session.

## Suggested validation sequence

1. Compile and resolve any errors reported by your MetaEditor build.
2. In Strategy Tester, verify session boundaries, POC placement, the open-bias decision, four-candle expiry, volume-spike rejection, stop placement, and the 1.5R target.
3. Test multiple market regimes and symbols with realistic commission, spread, and slippage settings.
4. Check the broker's economic-calendar availability and confirm the News status line behaves as expected.
5. Forward-test on demo before deciding whether the strategy is suitable for live use.

The EA source is provided for implementation and testing. It has not been compiled against your specific MT5 terminal/broker build in this environment.
